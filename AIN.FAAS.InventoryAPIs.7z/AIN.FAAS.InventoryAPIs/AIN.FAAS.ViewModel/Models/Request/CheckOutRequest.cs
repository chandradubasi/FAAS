﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AIN.FAAS.ViewModel.Models.Request
{
    public class CheckOutRequest
    {
        public string[] SGTIN { get; set; }
    }
}
